import React from "react";
import { ChevronDown, Search } from "lucide-react";

export default function TopBar() {
  return (
    <header className="h-14 bg-white border-b border-gray-100 flex items-center justify-between px-5">
      <div className="flex items-center gap-2.5">
        <button className="flex items-center gap-2 h-9 px-3 rounded-lg hover:bg-gray-50 transition">
          <div className="w-6 h-6 rounded-md bg-purple-100 flex items-center justify-center text-[10px] font-bold text-purple-700">
            VE
          </div>
          <span className="text-[13px] font-bold text-black">ORGANIZATION</span>
          <span className="text-[13px] font-semibold text-gray-500">Victor Ezealor</span>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </button>
      </div>
      <div className="flex items-center gap-4">
        <span className="bg-gray-100 text-gray-700 text-[11px] font-extrabold px-2.5 py-1 rounded-full">FREE</span>
        <span className="text-[13px] font-semibold text-gray-500">8 app credits</span>
        <button className="h-9 px-4 bg-black text-white text-[13px] font-bold rounded-lg hover:bg-gray-800 transition">
          Upgrade
        </button>
      </div>
    </header>
  );
}