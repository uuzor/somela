import React, { useState, useRef, useEffect } from "react";
import { Sparkles, X, ImageIcon, Wand2, Shirt, User, Palette, ArrowUp, Paperclip } from "lucide-react";
import MessageBubble from "@/components/chat/MessageBubble";

const suggestions = [
  { icon: Shirt, label: "Create a professional fashion photo with this product", color: "text-teal-600 bg-teal-50" },
  { icon: ImageIcon, label: "Put this product on this model", color: "text-pink-600 bg-pink-50" },
  { icon: User, label: "I want to create an AI model", color: "text-purple-600 bg-purple-50" },
  { icon: Palette, label: "Change the color of this garment", color: "text-red-600 bg-red-50" },
];

const shortcuts = [
  {
    label: "Product to Model",
    sub: "Turn wearable product images into professional model photography",
    image: "https://images.unsplash.com/photo-1581338834647-b0fb40704e21?w=400&h=400&fit=crop",
  },
  {
    label: "Try-On",
    sub: "Visualize how an outfit worn by one model looks on different models",
    image: "https://images.unsplash.com/photo-1485462537746-965f00f7f9d2?w=400&h=400&fit=crop",
  },
  {
    label: "Create Model",
    sub: "Create a unique AI model using a text prompt or reference image",
    image: "https://images.unsplash.com/photo-1492288991661-058aa541ff43?w=400&h=400&fit=crop",
  },
  {
    label: "Image to Video",
    sub: "Turn your results into a short motion clip",
    image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop",
  },
];

const sampleReply = (text) => ({
  role: "assistant",
  text: `Here are some pieces matching "${text}". I found these based on style, availability and price.`,
  products: [
    { id: 1, name: "Relaxed Zip Jacket", price: 82, rating: 4.8, image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=200&h=200&fit=crop", sale: true },
    { id: 2, name: "Heavy Everyday Hoodie", price: 58, rating: 4.9, image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=200&h=200&fit=crop", sale: false },
    { id: 3, name: "Cozy Baggy Pants", price: 120, rating: 4.9, image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=200&h=200&fit=crop", sale: false },
    { id: 4, name: "Knit Cardigan", price: 72, rating: 4.7, image: "https://images.unsplash.com/photo-1434389677669-e08b4cda3a3e?w=200&h=200&fit=crop", sale: false },
  ],
});

export default function ChatInterface() {
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState([]);
  const [showBanner, setShowBanner] = useState(true);
  const scrollRef = useRef(null);
  const isChatMode = messages.length > 0;

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const sendMessage = (text) => {
    if (!text.trim()) return;
    setMessages((m) => [...m, { role: "user", text }, sampleReply(text)]);
    setPrompt("");
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 relative">
      {/* Gradient bg */}
      <div
        className="absolute inset-0 opacity-60 pointer-events-none"
        style={{
          background:
            "radial-gradient(circle at 25% 20%, #e9fce9 0%, transparent 40%), radial-gradient(circle at 75% 15%, #fde6f3 0%, transparent 45%), radial-gradient(circle at 50% 60%, #fff8d6 0%, transparent 50%)",
        }}
      />

      {/* Chat / Landing */}
      <div ref={scrollRef} className="relative flex-1 overflow-y-auto">
        {!isChatMode ? (
          <div className="max-w-4xl mx-auto px-8 pt-8 pb-4">
            {showBanner && (
              <div className="w-full bg-white/80 backdrop-blur border border-gray-100 rounded-xl px-4 py-2.5 flex items-center gap-3 mb-12">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                <p className="text-[13px] font-semibold text-gray-700 flex-1">
                  Introducing Elements: Start creating with curated models, styles, poses, and more.{" "}
                  <span className="text-purple-600 font-bold cursor-pointer">Explore Elements →</span>
                </p>
                <button onClick={() => setShowBanner(false)}>
                  <X className="w-4 h-4 text-gray-400 hover:text-black" />
                </button>
              </div>
            )}

            <h1 className="text-center text-[40px] font-extrabold text-black mb-8 tracking-tight" style={{ fontFamily: "ui-serif, Georgia, serif" }}>
              What will you create today?
            </h1>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto px-6 py-6 space-y-5">
            {messages.map((m, i) => (
              <MessageBubble key={i} message={m} />
            ))}
          </div>
        )}
      </div>

      {/* Bottom: suggestions + input */}
      <div className="relative max-w-3xl w-full mx-auto px-6 pb-6">
        {!isChatMode && (
          <>
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-3 mb-4">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage(prompt)}
                placeholder="Describe anything you want to create..."
                className="w-full text-[14px] font-medium text-gray-800 placeholder-gray-400 outline-none px-2 py-3 mb-2"
              />
              <div className="flex items-center justify-between">
                <button className="flex items-center gap-1.5 text-[12px] font-bold text-gray-600 hover:text-black transition px-2.5 py-1.5 rounded-lg hover:bg-gray-50">
                  <ImageIcon className="w-4 h-4" /> Add images
                </button>
                <button
                  onClick={() => sendMessage(prompt)}
                  className="flex items-center gap-1.5 bg-black text-white text-[13px] font-bold px-4 py-2 rounded-xl hover:bg-gray-800 transition"
                >
                  <Wand2 className="w-3.5 h-3.5" /> Generate
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2.5 mb-10">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => sendMessage(s.label)}
                  className="flex items-center gap-2 bg-white border border-gray-200 rounded-full pl-2.5 pr-3.5 py-2 text-[12px] font-semibold text-gray-700 hover:border-gray-400 hover:shadow-sm transition"
                >
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center ${s.color}`}>
                    <s.icon className="w-3.5 h-3.5" />
                  </span>
                  {s.label}
                </button>
              ))}
            </div>

            {/* Studio Shortcuts */}
            <div>
              <h2 className="text-[16px] font-extrabold text-black mb-4">Studio Shortcuts</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                {shortcuts.map((s, i) => (
                  <button key={i} className="group rounded-2xl overflow-hidden aspect-square relative text-left">
                    <img src={s.image} alt={s.label} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-3.5">
                      <p className="text-[14px] font-extrabold text-white mb-1">{s.label}</p>
                      <p className="text-[11px] font-medium text-gray-200 leading-snug line-clamp-2">{s.sub}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {isChatMode && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-3">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage(prompt)}
              placeholder="Ask for outfit ideas or anything you need..."
              className="w-full text-[14px] font-medium text-gray-800 placeholder-gray-400 outline-none px-2 py-2.5 mb-2"
            />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button className="flex items-center gap-1.5 text-[11px] font-bold text-gray-500 hover:text-black transition">
                  <Paperclip className="w-3.5 h-3.5" /> Attach
                </button>
                <button className="flex items-center gap-1.5 text-[11px] font-bold text-gray-500 hover:text-black transition">
                  <ImageIcon className="w-3.5 h-3.5" /> Images
                </button>
              </div>
              <button
                onClick={() => sendMessage(prompt)}
                className="w-8 h-8 bg-black rounded-full flex items-center justify-center hover:bg-gray-800 transition"
              >
                <ArrowUp className="w-4 h-4 text-white" strokeWidth={2.5} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}