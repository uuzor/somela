import React from "react";
import { Home, Bot, Wand2, Images, Layers, Code, CircleHelp } from "lucide-react";

const navItems = [
  { icon: Home, label: "Home", active: true },
  { icon: Bot, label: "Agent" },
  { icon: Wand2, label: "Studio" },
  { icon: Images, label: "Gallery" },
  { icon: Layers, label: "Elements" },
  { icon: Code, label: "API" },
  { icon: CircleHelp, label: "Help" },
];

export default function SideNav() {
  return (
    <nav className="w-16 shrink-0 bg-[#1A1A1A] flex flex-col items-center justify-between py-5">
      <div className="flex flex-col items-center gap-1">
        <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center mb-4">
          <span className="text-black text-sm font-extrabold">N</span>
        </div>
        {navItems.map((item, i) => (
          <button
            key={i}
            title={item.label}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition ${
              item.active ? "bg-white/10 text-white" : "text-gray-500 hover:text-white hover:bg-white/5"
            }`}
          >
            <item.icon className="w-5 h-5" strokeWidth={1.8} />
          </button>
        ))}
      </div>
      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-white text-[11px] font-bold">
        V
      </div>
    </nav>
  );
}