import React from "react";
import { ShoppingBag, Wand2, Star } from "lucide-react";

export default function ProductWidget({ products }) {
  return (
    <div className="mt-2 grid grid-cols-2 gap-2.5 max-w-md">
      {products.map((p) => (
        <div key={p.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="aspect-square bg-gray-50 relative">
            <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
            {p.sale && (
              <span className="absolute top-1.5 left-1.5 bg-purple-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
                Sale
              </span>
            )}
          </div>
          <div className="p-2">
            <p className="text-[11px] font-bold text-black leading-tight line-clamp-1">{p.name}</p>
            <div className="flex items-center justify-between mt-0.5 mb-1.5">
              <span className="text-[12px] font-extrabold text-black">${p.price}</span>
              <div className="flex items-center gap-0.5">
                <Star className="w-2.5 h-2.5 fill-yellow-400 text-yellow-400" />
                <span className="text-[10px] font-bold text-gray-500">{p.rating}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button className="flex-1 h-7 bg-black text-white text-[10px] font-bold rounded-lg flex items-center justify-center gap-1 hover:bg-gray-800 transition">
                <ShoppingBag className="w-3 h-3" /> Buy
              </button>
              <button className="h-7 px-2.5 bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-bold rounded-lg flex items-center gap-1 hover:bg-purple-100 transition">
                <Wand2 className="w-3 h-3" /> Try-On
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}