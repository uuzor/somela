import React from "react";
import { X, ChevronDown } from "lucide-react";
import ProductCard from "@/components/dashboard/ProductCard";

const products = [
  {
    id: 1,
    title: "Relaxed Zip Jacket",
    price: 82,
    description: "Minimal zip jacket with a relaxed fit.",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=530&fit=crop",
    rating: 4.8,
    sold: "1K",
    isSale: true,
  },
  {
    id: 2,
    title: "Heavy Everyday Hoodie",
    price: 55,
    description: "Thick hoodie for daily comfort.",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&h=530&fit=crop",
    rating: 4.9,
    sold: "1.4K",
    isSale: false,
  },
  {
    id: 3,
    title: "Cozy Zip Hoodie",
    price: 64,
    description: "Soft zip hoodie with a clean look.",
    image: "https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?w=400&h=530&fit=crop",
    rating: 4.8,
    sold: "900",
    isSale: false,
  },
  {
    id: 4,
    title: "Varsity Knit Jacket",
    price: 96,
    description: "Modern knit with varsity details.",
    image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=400&h=530&fit=crop",
    rating: 4.9,
    sold: "12K",
    isSale: false,
  },
  {
    id: 5,
    title: "Classic Button Shirt",
    price: 86,
    description: "Clean button shirt with a relaxed cut.",
    image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&h=530&fit=crop",
    rating: 4.5,
    sold: "580",
    isSale: true,
  },
  {
    id: 6,
    title: "Knit Cardigan",
    price: 72,
    description: "Simple cardigan for easy layering.",
    image: "https://images.unsplash.com/photo-1434389677669-e08b4cda3a3e?w=400&h=530&fit=crop",
    rating: 4.9,
    sold: "1.1K",
    isSale: false,
  },
];

export default function ProductGrid({ filters, setFilters }) {
  const activeFilters = [];
  if (filters.size) activeFilters.push({ label: filters.size, key: "size" });
  if (filters.availability && filters.availability !== "All") activeFilters.push({ label: filters.availability, key: "availability" });
  if (filters.price) activeFilters.push({ label: filters.price, key: "price" });

  return (
    <div className="flex-1 min-w-0 px-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-[13px] text-gray-400 mb-4 font-semibold">
        <span>Home</span>
        <span>›</span>
        <span className="text-black font-bold">Products</span>
      </div>

      {/* Filters bar */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[13px] font-bold text-black">Applied Filters :</span>
          {filters.size && (
            <FilterChip label={filters.size} onRemove={() => setFilters((f) => ({ ...f, size: "" }))} />
          )}
          <FilterChip label="All" onRemove={() => {}} />
          {filters.price && (
            <FilterChip label={filters.price} onRemove={() => setFilters((f) => ({ ...f, price: "" }))} />
          )}
        </div>
        <div className="flex items-center gap-1.5 text-[13px] text-gray-500 font-semibold">
          <span>Sort By</span>
          <button className="flex items-center gap-0.5 font-bold text-black">
            Popularity <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}

function FilterChip({ label, onRemove }) {
  return (
    <span className="inline-flex items-center gap-1 bg-gray-50 border border-gray-200 text-[12px] font-bold text-gray-800 px-3 py-1.5 rounded-full">
      {label}
      <button onClick={onRemove}>
        <X className="w-3 h-3 text-gray-500 hover:text-black" />
      </button>
    </span>
  );
}