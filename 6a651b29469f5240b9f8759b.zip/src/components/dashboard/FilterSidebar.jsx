import React from "react";
import { ChevronDown } from "lucide-react";

const categories = [
  { name: "Tops", count: 12 },
  { name: "Bottoms", count: 9 },
  { name: "Outerwear", count: 5 },
  { name: "Shirts", count: 8 },
  { name: "Dresses", count: 17 },
  { name: "Hoodies", count: 6 },
  { name: "Accessories", count: 4 },
];

const sizes = ["S", "M", "L", "XL"];
const availabilities = ["All", "Discount", "In Stock"];
const prices = ["Under $50", "$50 - $100", "$110 - $150", "$150+"];

export default function FilterSidebar({ filters, setFilters }) {
  return (
    <aside className="w-[210px] shrink-0 pr-5 border-r border-gray-100 overflow-y-auto hidden lg:block space-y-4">
      {/* Category */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-black">Category</h3>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </div>
        <div className="space-y-2">
          {categories.map((cat) => (
            <label key={cat.name} className="flex items-center gap-2 cursor-pointer group">
              <input
                type="checkbox"
                checked={filters.categories.includes(cat.name)}
                onChange={() => {
                  setFilters((f) => ({
                    ...f,
                    categories: f.categories.includes(cat.name)
                      ? f.categories.filter((c) => c !== cat.name)
                      : [...f.categories, cat.name],
                  }));
                }}
                className="w-3.5 h-3.5 rounded border-gray-300 text-black focus:ring-black accent-black"
              />
              <span className="text-[13px] font-semibold text-gray-700 group-hover:text-black transition">{cat.name}</span>
              <span className="text-[11px] font-bold text-gray-400 ml-auto">{cat.count}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Size */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-black">Size</h3>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </div>
        <div className="space-y-2">
          {sizes.map((size) => (
            <label key={size} className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="size"
                checked={filters.size === size}
                onChange={() => setFilters((f) => ({ ...f, size }))}
                className="w-3.5 h-3.5 border-gray-300 text-black focus:ring-black accent-black"
              />
              <span className="text-[13px] font-semibold text-gray-700 group-hover:text-black transition">{size}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Availability */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-black">Availability</h3>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </div>
        <div className="space-y-2">
          {availabilities.map((a) => (
            <label key={a} className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="availability"
                checked={filters.availability === a}
                onChange={() => setFilters((f) => ({ ...f, availability: a }))}
                className="w-3.5 h-3.5 border-gray-300 text-black focus:ring-black accent-black"
              />
              <span className="text-[13px] font-semibold text-gray-700 group-hover:text-black transition">{a}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Price */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-black">Price</h3>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </div>
        <div className="space-y-2">
          {prices.map((p) => (
            <label key={p} className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="price"
                checked={filters.price === p}
                onChange={() => setFilters((f) => ({ ...f, price: p }))}
                className="w-3.5 h-3.5 border-gray-300 text-black focus:ring-black accent-black"
              />
              <span className="text-[13px] font-semibold text-gray-700 group-hover:text-black transition">{p}</span>
            </label>
          ))}
        </div>
      </div>
    </aside>
  );
}