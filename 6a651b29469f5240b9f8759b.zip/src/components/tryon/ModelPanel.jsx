import React, { useState } from "react";
import { Upload, Check } from "lucide-react";

const models = [
  {
    id: "m1",
    name: "Aria",
    image: "https://images.unsplash.com/photo-1488161628813-04466f872be2?w=120&h=150&fit=crop",
  },
  {
    id: "m2",
    name: "Leo",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=150&fit=crop",
  },
  {
    id: "m3",
    name: "Mia",
    image: "https://images.unsplash.com/photo-1504593811423-6dd665756598?w=120&h=150&fit=crop",
  },
  {
    id: "m4",
    name: "Kai",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2f?w=120&h=150&fit=crop",
  },
];

export default function ModelPanel({ selectedModel, setSelectedModel }) {
  return (
    <div className="border-b border-gray-100 pb-4 mb-4">
      <div className="flex items-center justify-between mb-3.5">
        <h3 className="text-[12px] font-extrabold uppercase tracking-wider text-black">Models</h3>
        <span className="text-[11px] font-semibold text-gray-400">{models.length} available</span>
      </div>
      <div className="grid grid-cols-4 gap-2.5">
        {models.map((m) => (
          <button
            key={m.id}
            onClick={() => setSelectedModel(m)}
            className={`relative rounded-xl overflow-hidden aspect-[3/4] transition-all ${
              selectedModel?.id === m.id ? "ring-2 ring-black" : "ring-1 ring-gray-100 hover:ring-gray-300"
            }`}
          >
            <img src={m.image} alt={m.name} className="w-full h-full object-cover" />
            {selectedModel?.id === m.id && (
              <div className="absolute top-1 right-1 w-4 h-4 bg-black rounded-full flex items-center justify-center">
                <Check className="w-2.5 h-2.5 text-white" />
              </div>
            )}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-1.5 py-1">
              <span className="text-[10px] font-bold text-white">{m.name}</span>
            </div>
          </button>
        ))}
      </div>
      <button className="w-full mt-2.5 h-9 border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center gap-1.5 text-[12px] font-bold text-gray-500 hover:border-gray-400 hover:text-black transition">
        <Upload className="w-3.5 h-3.5" />
        Upload Your Photo
      </button>
    </div>
  );
}