import React from "react";
import { Trash2 } from "lucide-react";

const outfitPieces = [
  {
    id: "top",
    label: "Top",
    name: "Heavy Everyday Hoodie",
    price: "$58",
    thumbnail: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=80&h=80&fit=crop",
    colors: ["#1f3a2e", "#000000", "#8B7355", "#4a4a4a"],
    sizes: ["S", "M", "L", "XL"],
    selectedColor: "#1f3a2e",
    selectedSize: "M",
  },
  {
    id: "bottom",
    label: "Bottom",
    name: "Cozy Baggy Pants",
    price: "$120",
    thumbnail: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=80&h=80&fit=crop",
    colors: ["#000000", "#4a4a4a", "#8B7355"],
    sizes: ["S", "M", "L", "XL"],
    selectedColor: "#000000",
    selectedSize: "M",
  },
];

export default function OutfitPanel({ outfit, setOutfit }) {
  const updatePiece = (id, field, value) => {
    setOutfit((o) => o.map((p) => (p.id === id ? { ...p, [field]: value } : p)));
  };

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="flex items-center justify-between mb-3.5">
        <h3 className="text-[12px] font-extrabold uppercase tracking-wider text-black">Selected Clothes</h3>
        <span className="text-[11px] font-semibold text-gray-400">{outfit.length} pieces</span>
      </div>

      <div className="space-y-3">
        {outfit.map((piece) => (
          <div key={piece.id} className="bg-gray-50 rounded-2xl border border-gray-100 p-3.5">
            <div className="flex items-center gap-3 mb-3">
              <img src={piece.thumbnail} className="w-12 h-12 rounded-lg object-cover" alt="" />
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-wide text-gray-400">{piece.label}</p>
                <p className="text-[13px] font-bold text-black leading-tight truncate">{piece.name}</p>
                <p className="text-[12px] font-extrabold text-black">{piece.price}</p>
              </div>
              <button className="text-gray-400 hover:text-black transition">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Color */}
            <div className="mb-2.5">
              <p className="text-[10px] font-bold uppercase tracking-wide text-gray-500 mb-1.5">Color</p>
              <div className="flex items-center gap-2">
                {piece.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => updatePiece(piece.id, "selectedColor", c)}
                    className={`w-5 h-5 rounded-full border-2 transition ${
                      piece.selectedColor === c ? "border-black ring-1 ring-black ring-offset-1" : "border-gray-200"
                    }`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>

            {/* Size */}
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-gray-500 mb-1.5">Size</p>
              <div className="flex items-center gap-1.5">
                {piece.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => updatePiece(piece.id, "selectedSize", s)}
                    className={`min-w-7 h-7 px-2 rounded-lg text-[11px] font-bold transition ${
                      piece.selectedSize === s
                        ? "bg-black text-white"
                        : "bg-white border border-gray-200 text-gray-700 hover:border-gray-400"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}