import React, { useState } from "react";
import { Download, RotateCw } from "lucide-react";

const clothOptions = [
  { id: "c1", image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=100&h=100&fit=crop" },
  { id: "c2", image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=100&h=100&fit=crop" },
  { id: "c3", image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=100&h=100&fit=crop" },
  { id: "c4", image: "https://images.unsplash.com/photo-1434389677669-e08b4cda3a3e?w=100&h=100&fit=crop" },
  { id: "c5", image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=100&h=100&fit=crop" },
  { id: "c6", image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=100&h=100&fit=crop" },
];

export default function TryOnCanvas({ selectedModel }) {
  const [activeCloth, setActiveCloth] = useState("c1");

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full">
      {/* Canvas — fills to screen bottom */}
      <div className="flex-1 rounded-2xl bg-gray-50 border border-gray-100 relative overflow-hidden flex items-center justify-center min-h-0 mx-5 mt-5">
        {selectedModel ? (
          <img
            src={selectedModel.image.replace("w=120&h=150", "w=500&h=700")}
            alt="Model try-on"
            className="h-full w-auto object-contain max-w-full"
          />
        ) : (
          <p className="text-[13px] font-semibold text-gray-400">Select a model to begin</p>
        )}

        {/* Cloth overlay tag */}
        {selectedModel && (
          <div className="absolute bottom-4 left-4 bg-black/80 backdrop-blur rounded-xl px-3 py-2">
            <p className="text-[10px] font-bold uppercase tracking-wide text-gray-300">Now Wearing</p>
            <p className="text-[13px] font-extrabold text-white">{clothOptions.find((c) => c.id === activeCloth) && "Hoodie"}</p>
          </div>
        )}

        {/* Floating actions */}
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <button className="w-9 h-9 rounded-lg bg-white/90 backdrop-blur border border-gray-100 flex items-center justify-center text-gray-700 hover:bg-white transition">
            <RotateCw className="w-4 h-4" />
          </button>
          <button className="h-9 px-3 rounded-lg bg-black text-white text-[12px] font-bold flex items-center gap-1.5 hover:bg-gray-800 transition">
            <Download className="w-3.5 h-3.5" /> Save Look
          </button>
        </div>
      </div>

      {/* Swap clothing — stacked below */}
      <div className="px-5 py-4">
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-[12px] font-extrabold uppercase tracking-wider text-black">Swap Clothing</h3>
          <span className="text-[11px] font-semibold text-gray-400">Click to try on</span>
        </div>
        <div className="flex items-center gap-3 overflow-x-auto pb-1">
          {clothOptions.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCloth(c.id)}
              className={`shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                activeCloth === c.id ? "border-black shadow-md" : "border-gray-100 hover:border-gray-300"
              }`}
            >
              <img src={c.image} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}