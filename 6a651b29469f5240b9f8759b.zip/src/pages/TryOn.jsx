import React, { useState } from "react";
import Navbar from "@/components/dashboard/Navbar";
import TryOnCanvas from "@/components/tryon/TryOnCanvas";
import ModelPanel from "@/components/tryon/ModelPanel";
import OutfitPanel from "@/components/tryon/OutfitPanel";
import AIAssistant from "@/components/dashboard/AIAssistant";

const defaultOutfit = [
  {
    id: "top",
    label: "Top",
    name: "Heavy Everyday Hoodie",
    price: "$58",
    thumbnail: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=80&h=80&fit=crop",
    colors: ["#1f3a2e", "#000000", "#8B7355", "#4a4a4a"],
    sizes: ["S", "M", "L", "XL"],
    selectedColor: "#1f3a2e",
    selectedSize: "M",
  },
  {
    id: "bottom",
    label: "Bottom",
    name: "Cozy Baggy Pants",
    price: "$120",
    thumbnail: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=80&h=80&fit=crop",
    colors: ["#000000", "#4a4a4a", "#8B7355"],
    sizes: ["S", "M", "L", "XL"],
    selectedColor: "#000000",
    selectedSize: "M",
  },
];

export default function TryOn() {
  const [selectedModel, setSelectedModel] = useState({
    id: "m1",
    name: "Aria",
    image: "https://images.unsplash.com/photo-1488161628813-04466f872be2?w=120&h=150&fit=crop",
  });
  const [outfit, setOutfit] = useState(defaultOutfit);

  return (
    <div className="h-screen flex flex-col bg-white overflow-hidden">
      <Navbar />
      <div className="flex flex-1 overflow-hidden">
        {/* Left: Canvas (widest) */}
        <TryOnCanvas selectedModel={selectedModel} />

        {/* Middle: Models + Selected Clothes */}
        <div className="w-[260px] shrink-0 border-l border-gray-100 px-4 py-5 flex flex-col">
          <ModelPanel selectedModel={selectedModel} setSelectedModel={setSelectedModel} />
          <OutfitPanel outfit={outfit} setOutfit={setOutfit} />
        </div>

        {/* Right: AI Assistant */}
        <AIAssistant />
      </div>
    </div>
  );
}